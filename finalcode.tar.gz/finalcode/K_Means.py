import matplotlib.pyplot as plt           # plotting library matplotlib
import numpy as np                        # statistics library
import seaborn as sns;sns.set()           # graphics and visualization library
import random as r
import math 
from SAX_FINAL import *
#from JSAnimation import IPython_display
#from matplotlib import animation

# define points here......

# Uncomment the below for randomized points
'''
points = np.vstack(((np.random.randn(150,2)*0.75 + np.array([1,0])),
	(np.random.randn(50,2)*0.25+np.array([-0.5,0.5])),
	(np.random.randn(50,2)*0.5 + np.array([-0.5,-0.5]))))

temp_points = np.random.randn(5,2)
'''
#points = [[1,0],[2,1],[3,2],[5,3]]


'''
for SAX INPUT USE THE FOLLOWING CODE:

# input s the string
# output points containing decimal equivalent

points = []
for i in s:
	points.append([])
	points[i].append(ord(i)-97)

for i in range(10):
	points[i].append(i)
'''


# Hash Function is defined below
def Hashfunction(a):
	return ord(a)-97




# input from SAX algorithm is fed into K-Means

points = []
temp_string = SAX_String
t=0
for c in temp_string:
	points.append([Hashfunction(c),t])
	t = t + 1

print temp_string
print points


'''
points = []
for i in range(10):
	points.append([])
	points[i].append(r.random())

for i in range(10):
	points[i].append(i)

'''

# Points to be defined here:
#points = np.vstack([[1,1],[2,2],[3,3],[2.5,2.5]])      # convert to Numpy array stack to make processing easier

#print temp_points[0][0]
#print temp_points

# print points

'''
plt.scatter(points[:,0],points[:,1])
ax = plt.gca()
ax.add_artist(plt.Circle(np.array([1, 0]), 0.75/2, fill=False, lw=3))
ax.add_artist(plt.Circle(np.array([-0.5, 0.5]), 0.25/2, fill=False, lw=3))
ax.add_artist(plt.Circle(np.array([-0.5, -0.5]), 0.5/2, fill=False, lw=3))

# plt.show()
'''

# function to initialize random centroids
def initialize_centroids(p,k):
	# returns k centroids from the initial points
	#centroids = p
	#np.random.shuffle(centroids)
	#r.shuffle(centroids)
	#return centroids[:k]
	return r.sample(p,k)

# print initialize_centroids(points,3)


def eucl_dist(x,y):
	#	print x[1]
	#print y[1]
	d1 = pow(x[0]-y[0],2)
	d2 = pow(x[1]-y[1],2)
	return math.sqrt(abs(d1-d2))




# function 
def closest_centroid(points,centroids):
	# returns an array containing the index to the nearest 
	# centroid for each point
	'''
	distances = np.sqrt(((points-centroids[:][np.newaxis])**2).sum(axis=2))
	return np.argmin(distances,axis=0)
	'''
	# print centroids
	min_centr_points = []
	for i in points:
		min_dist=1e9
		
		for j in centroids:
			if eucl_dist(i,j)<min_dist:
				min_dist = eucl_dist(i,j)
				min_cnetr = j
		min_centr_points.append(min_cnetr)

	return min_centr_points





def move_centroids(points,closest,centroids):
	
	#return np.array([points[closest==k].mean(axis=0) for k in range(centroids.shape[0])])
	'''
	points = np.array(points)
	closest = np.array(closest)
	centroids = np.array(centroids)

	return np.array([points[closest==k].mean for k in range(centroids)])
	'''
	new_centroids = []
	for k in centroids:
		# print k
		index_list = []
		index_list = [i for i,x in enumerate(closest) if x==k]
		# print index_list
		s = [0.0,0]
		for x in index_list:
			s[0] = s[0] + points[x][0]
			s[1] = s[1] + points[x][1]

		# print s	
		# print new_centroids
		new_centroids.append([s[0]/len(index_list),s[1]/len(index_list)])

	return new_centroids


#plt.scatter(points[:,0],points[:,1])
#c = initialize_centroids(points,3)
#plt.scatter(centroids[:,0],centroids[:,1],c='r',s=100)

#plt.show()


#print closest_centroid(points,c)

#plt.subplot(2,1,1)
#plt.scatter(points[:][0],points[:][1])


# K value in K_Means 
K = 6
centroids = initialize_centroids(points,K)
#print centroids

#print centroids
#plt.scatter(centroids[:][0],centroids[:][1],c='r',s=100)
#plt.show()
# c_extended = c[: , np.newaxis, :]
#print c_extended



#plt.subplot(2,1,2)
#plt.scatter(points[:,0],points[:,1])
#plt.scatter(points[:][0],points[:][1])

closest = closest_centroid(points,centroids)
#print points
#print closest

#print "points"
#print points
#print "closest centroids:"
#print closest
i = 10
while(i):
	centroids = move_centroids(points,closest,centroids)
	closest = closest_centroid(points,centroids)
#	print centroids
	i = i-1
#plt.scatter(centroids[:][0],centroids[:][1],c='r',s=100)



#plt.show()  

print points


x = [p[0] for p in points]
#print x

y = [p[1] for p in points]
#print y

plt.scatter(x,y,label='plot',color='k')
#plt.show()



x1 = [p[0] for p in centroids]
y1 =  [p[1] for p in centroids]

plt.scatter(x1,y1,label='plot',color='r')

plt.show()
print centroids






'''
fig = plt.figure()
ax = plt.axes(xlim=(-4,4),ylim=(-4,4))
centroids = initialize_centroids(points,3)

def init():
	return 

def animate(i):
	global centroids
	closest = closest_centroid(points,centroids)
	centroids = move_centroids(points,closest,centroids)
	ax.cla()
	ax.scatter(points[:,0],points[:,1],c=closest)
	ax.scatter(centroids[:,0],centroids[:,1],c='r',s=100)
	return 

animation.FuncAnimation(fig,animate,init_func=init,frames=10,interval=200,blit=True)

'''












