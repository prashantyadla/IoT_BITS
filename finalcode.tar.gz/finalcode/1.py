#  from __future__ import division
#  Frequent episode generation algorithm


# event sequence s
#
from matplotlib import pyplot as plt
from Markov import *

def mapUp(n):
	return chr(n+97)

s = [('E',31),('D',32),('F',34)]

input_num = data_input
s_temp = []

for i in input_num:
	s_temp.append(mapUp(i))

print "s_temp"
print s_temp
#s1 = ['E','D','F','A','B','C','E','F','C','D']
s1 = s_temp
# print s[0][1]

# print s[1][0]

# print s[2][1]

# window size win
win = 3
j = (len(s1)/win)

def freq(alpha):
	count = 0
	# print alpha
	for w in s2:
		i=0
		k = len(alpha)
		new_w = []
		while (i+k<=3):
			slobj = slice(i,i+k)
			new_w.append(w[slobj])
			i = i + 1
		count_win = 0
		#print new_w
		for q in new_w:
			# print q
			# print list(alpha)
			if list(alpha) == q:
				#print alpha
				#print q
				count_win = count_win + 1
				count = count + 1
				#print "local window count = ", w, (count_win/3.0)
	# print count
	# print j
	# return "global count = " , (count)/float(j)
	return count/float(j)




s2 = []

# print j
temp_list = []
x=0
for t in range(j):
	for i in range(win):
		temp_list.append(s1[x])
		x=x+1
	s2.append(temp_list)
	temp_list = []

# print freq('E')
#print s1
#print s2
# print s1

# minimum frequency min_fr
min_fr = 0.33



# output : collection F(s,win,min_fr) of frequent episodes

# 1) Compute C[0]

C = []
C.append(s1)

F = []
l = 1

#print freq('E')
#print freq(('E','D'))

thresh_freq = 0.3

thresh_conf = 0.5

ep_conf = []
ep_supp = []
for i in range(len(s1)-1):
	if freq(s1[i])>thresh_freq and freq((s1[i],s1[i+1]))>thresh_freq :
		f =  freq((s1[i],s1[i+1]))/freq(s1[i])
		s = freq((s1[i],s1[i+1]))
		print "confidence",f
		print "support",s
		ep_conf.append(f)
		ep_supp.append(s)

		if (f>=thresh_conf):
			print s1[i]+'--->'+s1[i+1]

plt.plot(ep_supp)
#plt.plot(ep_conf)
plt.plot(Markov_support)
#plt.plot(Markov_confidence)
#plt.title("support and confidence for episode rule minig")
plt.title("support metric in rule mining")
plt.xlabel("rule number")
#plt.ylabel("confidence/support")
plt.ylabel("support")
#plt.legend(['episode support','episode confidence','Markov Support','Markov Confidence'])
plt.legend(['Episode support','Markov support'])
plt.show()


'''
plt.plot(support)
plt.plot(ep_supp)
plt.show()
'''
'''
while 1:
	# Computer F.append()
	F.append(set(l))
	l = l+1
	# Compute C.append()

print C

'''

'''

def set(size):
	li = s1
	for i in li:



		#def freq(char):
	
'''











