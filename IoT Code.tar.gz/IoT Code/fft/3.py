import matplotlib.pyplot as plt
from scipy.fftpack import fft
import numpy as np


