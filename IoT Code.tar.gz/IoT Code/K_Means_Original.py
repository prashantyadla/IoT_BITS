import matplotlib.pyplot as plt           # plotting library matplotlib
import numpy as np                        # statistics library
import seaborn as sns;sns.set()           # graphics and visualization library
from SAX_FINAL import *
import time
from matplotlib import pyplot as plt
#from JSAnimation import IPython_display
#from matplotlib import animation



# define points here......

def Hashfunction(a):
	return ord(a)-97

points = []
temp_string = SAX_String 
t = 0
for c in temp_string:
	points.append([Hashfunction(c),t])
	t = t + 1


print temp_string
print points
points = np.vstack(points)

# Uncomment the below for randomized points

'''
points = np.vstack(((np.random.randn(150,2)*0.75 + np.array([1,0])),
	(np.random.randn(50,2)*0.25+np.array([-0.5,0.5])),
	(np.random.randn(50,2)*0.5 + np.array([-0.5,-0.5]))))
'''

# print the imported points
#print K_Means.ar


#points = np.vstack(np.random.randn(100,2))

# Points to be defined here:
#points = np.vstack([[1,1],[2,2],[3,3],[2.5,2.5]])      # convert to Numpy array stack to make processing easier

# print points
'''
plt.scatter(points[:,0],points[:,1])
ax = plt.gca()
ax.add_artist(plt.Circle(np.array([1, 0]), 0.75/2, fill=False, lw=3))
ax.add_artist(plt.Circle(np.array([-0.5, 0.5]), 0.25/2, fill=False, lw=3))
ax.add_artist(plt.Circle(np.array([-0.5, -0.5]), 0.5/2, fill=False, lw=3))

# plt.show()
'''

# function to initialize random centroids
def initialize_centroids(points,k):
	# returns k centroids from the initial points
	centroids = points.copy()
	# np.random.shuffle(centroids)
	return centroids[:k]

# print initialize_centroids(points,3)



# function 
def closest_centroid(points,centroids):
	# returns an array containing the index to the nearest 
	# centroid for each point
	distances = np.sqrt(((points-centroids[:,np.newaxis])**2).sum(axis=2))
	return np.argmin(distances,axis=0)


def move_centroids(points,closest,centroids):
	return np.array([points[closest==k].mean(axis=0) for k in range(centroids.shape[0])])


#plt.scatter(points[:,0],points[:,1])
# c = initialize_centroids(points,3)
#plt.scatter(centroids[:,0],centroids[:,1],c='r',s=100)

#plt.show()


#print closest_centroid(points,c)


K = 3    # number of clusters
X_AXIS = []    # no of clusters
Y_AXIS = []    # time required to run

while(K <= 10):
	centroids = []
	correct_centroids = []
	X_AXIS.append(K)
	start_time = time.time()
	plt.subplot(2,1,1)
	plt.scatter(points[:,0],points[:,1])

	centroids = initialize_centroids(points,K)
	plt.scatter(centroids[:,0],centroids[:,1],c='r',s=100)
# plt.show()
# c_extended = c[: , np.newaxis, :]
#print c_extended



	plt.subplot(2,1,2)
	plt.scatter(points[:,0],points[:,1])
	closest = closest_centroid(points,centroids)
	i = 10
	while(i):
		centroids = move_centroids(points,closest,centroids)
		closest = closest_centroid(points,centroids)
		i = i-1
	plt.scatter(centroids[:,0],centroids[:,1],c='r',s=100)

	
	print centroids
	Y_AXIS.append(time.time()-start_time)
	correct_centroids = centroids
	plt.show() 
	K = K+1


plt.plot(X_AXIS,Y_AXIS,marker='o')
plt.xlabel('number of cluster K')
plt.ylabel('time complexity in sec')
plt.title('Time Variance w.r.t K')
plt.show()

'''
fig = plt.figure()
ax = plt.axes(xlim=(-4,4),ylim=(-4,4))
centroids = initialize_centroids(points,3)

def init():
	return 

def animate(i):
	global centroids
	closest = closest_centroid(points,centroids)
	centroids = move_centroids(points,closest,centroids)
	ax.cla()
	ax.scatter(points[:,0],points[:,1],c=closest)
	ax.scatter(centroids[:,0],centroids[:,1],c='r',s=100)
	return 

animation.FuncAnimation(fig,animate,init_func=init,frames=10,interval=200,blit=True)
'''










		

