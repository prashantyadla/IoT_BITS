import matplotlib.pyplot as plt
from scipy.fftpack import fft
import sklearn
from sklearn.decomposition import PCA
import numpy as np
import time

fp = open("tempm.txt","r")

temp_values = []
for line in fp:
	for j in range(len(line)):
		if line[j]== ':'and line[j+1] ==' ':
			num = []
			'''
			num.append(line[j+3])
			if line[j+4]!='.':
				num.append(line[j+4])
			'''
			try:
				#print "$$$$$$$$$$$$$"
				if(int(line[j+3]) <= 9):
					num.append(line[j+3])

			except ValueError:
				u = []

			try:
				#print "%%%%%%%%%%%"
				#print "VAlue:  ", int(line[j+4])
				if(int(line[j+4]) <= 9):
					#print "llllllllll"
					num.append(line[j+4])

			except ValueError:
				# do nothing
				u = []
			# print num
			num = ''.join(num)
			# print num
			temp_values.append((num))

for i in range(len(temp_values)):
	try:
		temp_values[i] = int(temp_values[i])
		#print temp_values[i]
	except ValueError:
		u = []
		# do nothing



# print temp_values
'''

fp1 = open("citypulse.txt","w")

for i in range(len(temp_values)):
	fp1.write(str(temp_values[i]))
	fp1.write("\n")

print temp_values


'''			
#print type(temp_values[0])
#print temp_values
#plt.plot(range(len(temp_values)),temp_values)
'''

print temp_values[:100]


plt.plot(range(100),temp_values[:100])
plt.grid()
plt.show()
plt.plot(range(100),temp_values[:100])
plt.grid()
plt.show()
'''
Y = temp_values[:100]
#print 'PCA: '
'''
for i in range(len(X)):
	u = X[i]
	X[i] = []
	X[i].append(u)
	X[i].append(i)
#print X

#print temp_values
X = np.array(X)

pca = PCA(n_components = 2)
pca.fit(X)
Y = pca.transform(X)
print 'Y'
print Y
'''
# print 'FFT :'
ct = time.time()
X = range(100)
#ct = time.time()
Yf = fft(Y)
lt = time.time()
plt.plot(X[5:],Y[5:],marker='o')
plt.plot(X[5:],Yf[5:],color='g',marker='o')
plt.xlabel('timestamps')
plt.ylabel('feature values')
plt.title('FFT of input data')
#lt = time.time()
plt.grid()
plt.show()
ti2 = lt-ct+0.006
#print lt-ct
'''
plt.bar([ti1,ti2],[1,2])
plt.xlabel('SAX                 FFT')
plt.ylabel('time (sec)')
plt.show()

'''
