fp = open("tempm.txt","r")

temp_values = []
for line in fp:
	for j in range(len(line)):
		if line[j]== ':'and line[j+1] ==' ':
			num = []
			'''
			num.append(line[j+3])
			if line[j+4]!='.':
				num.append(line[j+4])
			'''
			try:
				#print "$$$$$$$$$$$$$"
				if(int(line[j+3]) <= 9):
					num.append(line[j+3])

			except ValueError:
				u = []

			try:
				#print "%%%%%%%%%%%"
				#print "VAlue:  ", int(line[j+4])
				if(int(line[j+4]) <= 9):
					#print "llllllllll"
					num.append(line[j+4])

			except ValueError:
				# do nothing
				u = []
			# print num
			num = ''.join(num)
			# print num
			temp_values.append((num))

for i in range(len(temp_values)):
	try:
		temp_values[i] = int(temp_values[i])
		#print temp_values[i]
	except ValueError:
		u = []
		# do nothing



# print temp_values
'''

fp1 = open("citypulse.txt","w")

for i in range(len(temp_values)):
	fp1.write(str(temp_values[i]))
	fp1.write("\n")

print temp_values


'''			
		
