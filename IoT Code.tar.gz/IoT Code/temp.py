import matplotlib.pyplot as plt
import numpy as np
import random as r
import math


# input to K-Means
'''
points = []
for i in range(10):
	points.append([])
	points[i].append(r.random())

for i in range(10):
	points[i].append(i)

print points
'''

# input to SAX:

'''
values = []

for i in range(100):
	values.append(r.random())

# print values
target = open("data.txt",'w')
target.write("id: Value")
target.write("\n")

for i in range(100):
	target.write(str(i)+": ")
	target.write(str(values[i]))
	target.write("\n")

target.close()

'''

values = []

read_t = open("data.txt",'r+')


x = read_t.readline()
# print x

for i in range(100):
	x = read_t.readline()
	u = 0
	while(x[u]!=':'):
		u = u + 1
	y = x[u+1:]
	values.append(y)
	# values[i][-1] = "\0"

'''
for j in range(100):
	print values[j]
'''

new_values = []
for j in values:
	new_values.append(float(j[1:-1]))

print "#########INPUT TEMPERATURE DATA############"
print new_values

print "###########################################"
	#j[-1] = '\0'
 # print new_values









