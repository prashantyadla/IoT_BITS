#!/usr/bin/env python

import os
import numpy as np
import math
import random
import time
from matplotlib import pyplot as plt
# from temp import *
from j import *


class DictionarySizeIsNotSupported(Exception): pass
class StringsAreDifferentLength(Exception): pass
class OverlapSpecifiedIsNotSmallerThanWindowSize(Exception): pass



# SAX MAIN CLASS
class SAX(object):
    """
    This class is for computing common things with the Symbolic
    Aggregate approXimation method.  In short, this translates
    a series of data to a string, which can then be compared with other
    such strings using a lookup table.
    """

    def __init__(self, wordSize, alphabetSize, epsilon ):

        if alphabetSize < 3 or alphabetSize > 20:
            raise DictionarySizeIsNotSupported()
        self.aOffset = ord('a')       # initial alphabet is 'a'
        self.wordSize = wordSize      # final wordsize for output
        self.alphabetSize = alphabetSize
        self.eps = epsilon
	# depending on wordsize, we need to breakup windows accordingly.
        self.breakpoints = {'3' : [-0.43, 0.43],					#breakpoints can be set according to ontology 
                            '4' : [-0.67, 0, 0.67],
                            '5' : [-0.84, -0.25, 0.25, 0.84],
                            '6' : [-0.97, -0.43, 0, 0.43, 0.97],
                            '7' : [-1.07, -0.57, -0.18, 0.18, 0.57, 1.07],
                            '8' : [-1.15, -0.67, -0.32, 0, 0.32, 0.67, 1.15],
                            '9' : [-1.22, -0.76, -0.43, -0.14, 0.14, 0.43, 0.76, 1.22],
                            '10': [-1.28, -0.84, -0.52, -0.25, 0, 0.25, 0.52, 0.84, 1.28],
                            '11': [-1.34, -0.91, -0.6, -0.35, -0.11, 0.11, 0.35, 0.6, 0.91, 1.34],
                            '12': [-1.38, -0.97, -0.67, -0.43, -0.21, 0, 0.21, 0.43, 0.67, 0.97, 1.38],
                            '13': [-1.43, -1.02, -0.74, -0.5, -0.29, -0.1, 0.1, 0.29, 0.5, 0.74, 1.02, 1.43],
                            '14': [-1.47, -1.07, -0.79, -0.57, -0.37, -0.18, 0, 0.18, 0.37, 0.57, 0.79, 1.07, 1.47],
                            '15': [-1.5, -1.11, -0.84, -0.62, -0.43, -0.25, -0.08, 0.08, 0.25, 0.43, 0.62, 0.84, 1.11, 1.5],
                            '16': [-1.53, -1.15, -0.89, -0.67, -0.49, -0.32, -0.16, 0, 0.16, 0.32, 0.49, 0.67, 0.89, 1.15, 1.53],
                            '17': [-1.56, -1.19, -0.93, -0.72, -0.54, -0.38, -0.22, -0.07, 0.07, 0.22, 0.38, 0.54, 0.72, 0.93, 1.19, 1.56],
                            '18': [-1.59, -1.22, -0.97, -0.76, -0.59, -0.43, -0.28, -0.14, 0, 0.14, 0.28, 0.43, 0.59, 0.76, 0.97, 1.22, 1.59],
                            '19': [-1.62, -1.25, -1, -0.8, -0.63, -0.48, -0.34, -0.2, -0.07, 0.07, 0.2, 0.34, 0.48, 0.63, 0.8, 1, 1.25, 1.62],
                            '20': [-1.64, -1.28, -1.04, -0.84, -0.67, -0.52, -0.39, -0.25, -0.13, 0, 0.13, 0.25, 0.39, 0.52, 0.67, 0.84, 1.04, 1.28, 1.64]
                            }
        self.beta = self.breakpoints[str(self.alphabetSize)]
        self.build_letter_compare_dict()
        self.scalingFactor = 1


# Main driver function for PAA
    def to_letter_rep(self, x):
        """
        Function takes a series of data, x, and transforms it to a string representation
        """
        (paaX, indices) = self.to_PAA(self.normalize(x))          # paaX is just the mean of values in each given window
        self.scalingFactor = np.sqrt((len(x) * 1.0) / (self.wordSize * 1.0))
	# return (self.alphabetize(paaX), indices)      
	# print indices[0][1]
	return self.alphabetize(paaX),indices
# Normalizing , Data Preprocessing Step
    def normalize(self, x):
        """
        Function will normalize an array (give it a mean of 0, and a
        standard deviation of 1) unless it's standard deviation is below
        epsilon, in which case it returns an array of zeros the length
        of the original array.
        """
        X = np.asanyarray(x)
        if X.std() < self.eps:
            return [0 for entry in X]
        return (X-X.mean())/X.std()         # mean/std_dev

# Mean finder of each sliding window
    def to_PAA(self, x):
        """
        Function performs Piecewise Aggregate Approximation on data set, reducing
        the dimension of the dataset x to w discrete levels. returns the reduced
        dimension data set, as well as the indices corresponding to the original
        data for each reduced dimension
        """
        n = len(x)			# length of given data
        stepFloat = n/float(self.wordSize)    # number of windows
        step = int(math.ceil(stepFloat))    # rounded integer value
        frameStart = 0     # initial Frame Number / Window Number
        approximation = []      # Final value to be returned, ie., the mean
        indices = []      # indices of start and end of each window
        i = 0
        while frameStart <= n-step:
            thisFrame = np.array(x[frameStart:int(frameStart + step)])       # array containing all values of current window/frame
            approximation.append(np.mean(thisFrame))        		     # calculating mean
            indices.append((frameStart, int(frameStart + step)))             # indices updations
            i += 1
            frameStart = int(i*stepFloat)                                    # Incrementing Next Frame
        return (np.array(approximation), indices)
# Converts output of PAA function to string based on existing ontology
    def alphabetize(self,paaX):
        """
        Converts the Piecewise Aggregate Approximation of x to a series of letters.
        """
        alphabetizedX = ''    # string value
        for i in range(0, len(paaX)):   # checking for correct range in breakpoints
            letterFound = False
            for j in range(0, len(self.beta)):
                if paaX[i] < self.beta[j]:
                    alphabetizedX += chr(self.aOffset + j)   # character 'a'+offset(j)
                    letterFound = True
                    break
            if not letterFound:
                alphabetizedX += chr(self.aOffset + len(self.beta))    # otherwise go to the end
        return alphabetizedX


# The below functions are not required as of now.They are used for comparision purposes only
# We can change them later accordingly

    def compare_strings(self, sA, sB):
        """
        Compares two strings based on individual letter distance
        Requires that both strings are the same length
        """
        if len(sA) != len(sB):
            raise StringsAreDifferentLength()
        list_letters_a = [x for x in sA]
        list_letters_b = [x for x in sB]
        mindist = 0.0
        for i in range(0, len(list_letters_a)):
            mindist += self.compare_letters(list_letters_a[i], list_letters_b[i])**2
        mindist = self.scalingFactor* np.sqrt(mindist)
        return mindist

    def compare_letters(self, la, lb):
        """
        Compare two letters based on letter distance return distance between
        """
        return self.compareDict[la+lb]

    def build_letter_compare_dict(self):
        """
        Builds up the lookup table to determine numeric distance between two letters
        given an alphabet size.  Entries for both 'ab' and 'ba' will be created
        and will have identical values.
        """

        number_rep = range(0,self.alphabetSize)
        letters = [chr(x + self.aOffset) for x in number_rep]
        self.compareDict = {}
        for i in range(0, len(letters)):
            for j in range(0, len(letters)):
                if np.abs(number_rep[i]-number_rep[j]) <=1:
                    self.compareDict[letters[i]+letters[j]] = 0
                else:
                    high_num = np.max([number_rep[i], number_rep[j]])-1
                    low_num = np.min([number_rep[i], number_rep[j]])
                    self.compareDict[letters[i]+letters[j]] = self.beta[high_num] - self.beta[low_num]

    def sliding_window(self, x, numSubsequences = None, overlappingFraction = None):
        if not numSubsequences:
            numSubsequences = 20
        self.windowSize = int(len(x)/numSubsequences)
        if not overlappingFraction:
            overlappingFraction = 0.9
        overlap = self.windowSize*overlappingFraction
        moveSize = int(self.windowSize - overlap)
        if moveSize < 1:
            raise OverlapSpecifiedIsNotSmallerThanWindowSize()
        ptr = 0
        n = len(x)
        windowIndices = []
        stringRep = []
        while ptr < n-self.windowSize+1:
            thisSubRange = x[ptr:ptr+self.windowSize]
            (thisStringRep,indices) = self.to_letter_rep(thisSubRange)
            stringRep.append(thisStringRep)
            windowIndices.append((ptr, ptr+self.windowSize))
            ptr += moveSize
        return (stringRep,windowIndices)

    def batch_compare(self, xStrings, refString):
        return [self.compare_strings(x, refString) for x in xStrings]

    def set_scaling_factor(self, scalingFactor):
        self.scalingFactor = scalingFactor

    def set_window_size(self, windowSize):
        self.windowSize = windowSize
     
        
        
# Main Function Begins here        
#length_of_string = 5        



#Obj = SAX(60,7,1e-6)        							# Create Object for SAX Usage



# Dataset reading starts from here



'''
# write to a file random temperature values
f = open("test.txt",'w')
for i in range(1000):
	f.write(str(random.uniform(1,100)))
	f.write('\n')

f.close()



# read from the file the temperature values: 
print "Temperature Values:"
f = open("test.txt",'r')
ar = []
for x in range(1000):
	ar.append(float(f.readline())+1)

# print ar

	#ar = [1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,6,6,6,6,10,100]     		# Any Given Array Can Be Inputted here

#print ar
'''



# SAX algorithm to be run here
y_axis = []
x_axis = []
length_of_string = 5

#x_axis.append(length_of_string)
#print "Printing From SAX"
#print temp_values
temp_values = temp_values[:100]
print temp_values
for i in range(10):
	start_time = time.time()
	x_axis.append(length_of_string)
	Obj = SAX(length_of_string,7,1e-6)
	SAX_String, final_indices = Obj.to_letter_rep(temp_values)
	y_axis.append(time.time()-start_time)
	length_of_string = length_of_string+5
	# x_axis.append(length_of_string)

#print SAX_String					# Returns 1) A String representing PAA representation of given Data
#print x_axis					#         2) List of tuples indicating start and end point of window
#print y_axis
#print SAX_String,"length: ",len(SAX_String)        
# print SAX_String,final_indices
        
# plotting the graph:
plt.plot(x_axis,y_axis,'r',marker='o')
plt.title('Time Complexity of SAX')
plt.ylabel('Time Required in sec')
plt.xlabel('Length of string')
plt.show()
#      







