import time
import sys
import numpy as np
from K_Means import *

from K_Means_Original import *

# ############ MAP EVENTS FROM K-MEANS TO EVENTS IN MARKOV MODEL ####################
'''
K_states = 7    # total number of possible events
x1 = 0
x2 = 0
num_inputs = len(centroids)
'''

sorted_centroids = (correct_centroids).tolist()
mapValue = 0
#sorted_centroids.sort(key=lambda x: x[1])


#print "Sorted Centroids: "
#print sorted_centroids

mapValue = 0
for i in range(len(sorted_centroids)):
	sorted_centroids[i].append(mapValue)
	mapValue = mapValue + 1

sorted_centroids.sort(key=lambda x: x[1])
new_sorted_list = sorted_centroids
#print "new_sorted_list:"
#print new_sorted_list
new_sorted_list.sort(key=lambda x: x[0])
print "new_sorted_list:"
print new_sorted_list

for i in range(len(new_sorted_list)-1):
	if new_sorted_list[i+1][0]-new_sorted_list[i][0] <= 0.5:
		new_sorted_list[i+1][2] = new_sorted_list[i][2]


print "Sorted Centroids with MapValue:"
print sorted_centroids


new_data_input = []

for x in sorted_centroids:
	new_data_input.append(x[2])


print "new data input:"
print new_data_input
####################################################################################


K_states = 10
x1 = 0
x2 = 0
#data_input = [3,3,3,6,6,4,3,3]
data_input = new_data_input
numb_inputs = 10


# Creates a 5*5 matrix
turn_out_matrix = [[0 for x in range(K_states)] for x in range(K_states)]  # not required


# Probability Matrix is defined below
prob_matrix = [[0 for x in range(K_states)] for x in range(K_states)]




# *******Markov Chain********
def MarkovChain():
	t = 0
	while t < numb_inputs-1:
		turn_out_matrix[data_input[t]][data_input[t+1]] += 1
		t += 1

	x1 = 0
	while x1<K_states:
		# Count the number of turn-outs for this value of X1
		x2 = 0
		numb_turn_outs = 0
		while x2 < K_states:
			numb_turn_outs += turn_out_matrix[x1][x2]
			x2 += 1

		# Calculate the prob for a particular turn-out 
		x2 = 0
		while x2 < K_states:
			if numb_turn_outs>0:
				prob_matrix[x1][x2] = float(turn_out_matrix[x1][x2])/numb_turn_outs
			else:
				prob_matrix[x1][x2] = 0.0

			x2 += 1
		x1 += 1


def PrintDataInput():
	x1 = 0
	column = "\nData input: "
	while x1<K_states:
		column += str(data_input[x1]	) + " "
		x1 += 1
	column += "\n"
	print (column)


def PrintTurnoutMatrix():
	# Print column cell-name
	print ("Transition matrix:")
	x1 = 0
	column = "        "
	while x1<K_states:
		column += "x2+" + str(x1) + ":   "
		x1 += 1
	print (column)


	x1 = 0
	while x1<K_states:
		x2 = 0
		column = "K1=" + str(x1) + ":    "
		while  x2<K_states:
			column += str(turn_out_matrix[x1][x2]) + "      "
			x2 += 1
		print (column)

		x1 += 1
	print ("\n")

def PrintProbMatrix():
	# Print column cell-names
	print ("Probability matrix:")
	x1 = 0
	column = "        "
	while x1<K_states:
		column += "X2="+str(x1) + "    "
		x1 += 1
	print (column)

	x1 = 0
	while x1<K_states:
		x2 = 0
		column = "X1="+str(x1)+":   "
		while x2<K_states:
			column += str(prob_matrix[x1][x2]) + "      "
			x2 += 1
		print (column)

		x1 += 1

	print ("\n" )





print ("______________Markov Chain__________")
PrintDataInput()
MarkovChain()
PrintTurnoutMatrix()
PrintProbMatrix()

print "Rules: "
thresh_supp = 0.6

support = []
confidence = []
for i in range(K_states):
	for j in range(K_states):
		if prob_matrix[i][j] >= thresh_supp:
			support.append([i,j,prob_matrix[i][j]])
			print i, '----->',j,"support: ",prob_matrix[i][j],"confidence: ",float((data_input.count(i))/float(numb_inputs))
			#print "count",data_input.count(i)
			#print "numb_inputs",numb_inputs
			#print float(data_input.count(i)/float(numb_inputs))
			confidence.append([i,j,(prob_matrix[i][j])/float((data_input.count(i)/float(numb_inputs)))])
			
			

print support
print confidence


Markov_support = []
Markov_confidence = []

for x in support:
	Markov_support.append(x[2])
for x in confidence:
	Markov_confidence.append(x[2])









