import matplotlib.pyplot as plt
from scipy.fftpack import fft
import numpy as np

x = range(9)
y = [2,2,2,2,4,6,2,2,2]


yf = fft(y)
print 'yf: '
print yf
plt.plot(x,yf)
plt.plot(x,y,marker='o')
plt.show()


